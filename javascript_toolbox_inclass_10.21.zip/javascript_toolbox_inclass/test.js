// pseudocode: half human/half computer language

// make multiple alert boxes appear around the screen

(button).on(click) {
  
}